// Logica pagina login (passwordless via OTP)
document.addEventListener('DOMContentLoaded', () => {
  const form      = document.getElementById('loginForm');
  const btnSubmit = document.getElementById('btnSubmit');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    hideAlert('alertMsg');

    const email = form.email.value.trim().toLowerCase();
    const emailRx = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRx.test(email)) {
      showAlert('alertMsg', t('email_invalid'), 'error');
      return;
    }

    setButtonLoading(btnSubmit, true);

    try {
      const res = await apiCall('/api/auth/login', 'POST', { email });

      sessionStorage.setItem('verifyContext', JSON.stringify({
        userId:  res.data.userId,
        purpose: res.data.purpose || 'login',
        email:   email,
        nome:    ''
      }));

      window.location.href = '/verify';
    } catch (err) {
      showAlert('alertMsg', err.message || t('error_generic'), 'error');
    } finally {
      setButtonLoading(btnSubmit, false);
    }
  });
});
